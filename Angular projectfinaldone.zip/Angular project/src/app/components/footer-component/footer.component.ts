import { Component } from '@angular/core';

@Component({
  selector: 'myfooter',
  templateUrl:'./footer.component.html',
  
})
export class FooterComponent { 
 }