package com.springmongo.collection;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="users_session")
public class UserLoginCollection {
	@Id
	String id;
	String userName;
	public UserLoginCollection(){}
	public UserLoginCollection(String id, String userName) {
		super();
		this.id = id;
		this.userName = userName;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}

	
}
