package com.springmongo.dao;

import com.springmongo.collection.AdvertisementCollection;
import com.springmongo.collection.UserCollection;
import com.springmongo.collection.UserLoginCollection;
import com.springmongo.entity.Advertisement;
import com.springmongo.entity.User;
import com.springmongo.entity.UserLogin;

public interface AdvertisementDao {
	public AdvertisementCollection postAd(Advertisement advertisement, String token);
}
