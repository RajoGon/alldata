package com.springmongo.service;

import java.util.ArrayList;
import java.util.List;

import com.springmongo.collection.ItemCollection;

public interface ItemService {
	public ArrayList<ItemCollection> getAllCategories();
}
