package com.springmongo.service;

import java.util.ArrayList;
import java.util.List;

import com.springmongo.collection.ActionCollection;
import com.springmongo.collection.ItemCollection;

public interface ActionService {
	public ArrayList<ActionCollection> getAllActions();
}
