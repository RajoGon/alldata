package com.springtest.springmongo.service;

public class UserService {

}
