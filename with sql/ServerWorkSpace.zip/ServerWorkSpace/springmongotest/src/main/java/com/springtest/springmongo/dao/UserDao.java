package com.springtest.springmongo.dao;

public class UserDao {

}
