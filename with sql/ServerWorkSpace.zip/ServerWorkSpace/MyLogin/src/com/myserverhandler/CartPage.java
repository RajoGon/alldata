package com.myserverhandler;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class CartPage extends HttpServlet {
	ServletContext ctx;
	public void init(ServletConfig config){
		this.ctx = config.getServletContext();
	}
	public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException{
		response.setContentType("text/html");
    	String username = request.getParameter("username");
    	PrintWriter out = response.getWriter();
    	System.out.println(request.getSession(false).getAttribute("username"));
    	String cbooks[] = (String[]) request.getSession(false).getAttribute("cbooks");
    	String hbooks[] = (String[]) request.getSession(false).getAttribute("hbooks");

    	out.println("<html>"
    			+ "<head>"
    			+ "<meta charset='ISO-8859-1'>"
    			+ "<title>Your Cart</title>"
    			+"</head>"
    			+ "<body>"
    			+ "<h1>Welcome "+ username+ "</h1>"
    			+ "</body>"
    			+ "</html>"
    			+ "<form action='controller?loggedin=false' method='post' >"
    			+"<h2>Your books are</h2>");
    	for(String a: cbooks){
    		out.append(""
        			+ "<p>"+a+"</p>"       			
       			);
    	}
    	for(String b: hbooks){
    		out.append(""
        			+ "<p>"+b+"</p>"       			
       			);
    	}
    	out.append( "<input type='submit' value='Logout'>"
    				+ "</form>"
    			);
    	
	}
	public void doGet(){
		
	}

}
